define([], function() {
  'use strict';

  var PageModule = function PageModule() {};

  PageModule.prototype.callComponent = function (id) {
    if (document.getElementById(id).style.display !== 'block') {
      document.getElementById(id).style.display = 'block';
    } else {
      document.getElementById(id).style.display = 'none';

    }
  }

  return PageModule;
});
