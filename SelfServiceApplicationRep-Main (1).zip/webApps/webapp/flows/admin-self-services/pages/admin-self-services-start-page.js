define([], function() {
  'use strict';

  var PageModule = function PageModule() {};



  PageModule.prototype.toTitleCase = function (str) {
    if (str != null) {
      let arr = str.split("_");
      let result = arr.map(e => { if (e.length > 3) return e.charAt(0).toUpperCase() + e.substr(1).toLowerCase(); else return e })
      return result.join(" ");
    }
    return str;

  };

  return PageModule;
});
