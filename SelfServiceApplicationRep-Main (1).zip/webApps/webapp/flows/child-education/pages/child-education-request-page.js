define([], function () {
  'use strict';

  var PageModule = function PageModule() { };

  PageModule.prototype.isEmpty = function (obj) {
    return !obj || obj == "";
  };

  PageModule.prototype.testData = function (obj) {
    console.log('test data is ', obj);
  };

  PageModule.prototype.calcUtilizedAmount = function (baseUtilizedAmount, receiptAmount) {
    console.log("================calcUtilizedAmount==================");
    if (PageModule.prototype.isEmpty(baseUtilizedAmount)) {
      baseUtilizedAmount = 0;
    }
    if (PageModule.prototype.isEmpty(receiptAmount)) {
      receiptAmount = 0;
    }
    return ((Number(baseUtilizedAmount) + Number(receiptAmount)).toFixed(2));
  };

  ///////////////////////////////////////////////////////////////////////////////////////////////
  //////////////////////////////////////////////////////////////////////////////////////////////
  PageModule.prototype.calcBaseUtilizedAmount = function (utilizedAmount, receiptAmount) {
    console.log("================calcBaseUtilizedAmount==================");
    if (!PageModule.prototype.isEmpty(utilizedAmount)) {
      if (!PageModule.prototype.isEmpty(receiptAmount)) {
        return (Number(utilizedAmount) - Number(receiptAmount)).toFixed(2);
      }
      return Number(utilizedAmount);
    }
    return 0;
  };

  ///////////////////////////////////////////////////////////////////////////////////////////////
  //////////////////////////////////////////////////////////////////////////////////////////////
  PageModule.prototype.calcBalanceAmount = function (utilizedAmount, eligibilityAmount) {
    console.log("================calcBaseUtilizedAmount==================");
    if (!PageModule.prototype.isEmpty(eligibilityAmount)) {
      if (!PageModule.prototype.isEmpty(utilizedAmount)) {
        return (Number(eligibilityAmount) - Number(utilizedAmount)).toFixed(2);
      }
      //  return Number(utilizedAmount);
    }
    return 0;
  };

  //////////////////////////////////////////////////////////////////////////////////////////
  PageModule.prototype.validReceiptAmount = function (eligibilityAmount, baseUtilizedAmount) {
    return {
      validate: (value) => {
        console.log("validReceiptAmount: ", value);
        let valid = true;
        console.log("baseUtilizedAmount: ", baseUtilizedAmount);
        if (!PageModule.prototype.isEmpty(eligibilityAmount)) {

          let balanceAmount = PageModule.prototype.calcBalanceAmount((baseUtilizedAmount + value), eligibilityAmount);
          console.log("balanceAmount ", balanceAmount);
          if (balanceAmount < 0) {
            valid = false;
            throw new Error(
              'Balance Amount become ' + balanceAmount + ". The amount you entered is more than your limit"
            );
          }

        } else if (PageModule.prototype.isEmpty(eligibilityAmount)) {
          valid = false;
          throw new Error(
            'Please Select Year, Child!'
          );
        }

        return valid;
      },
    };
  };


  /////////////////////////////////////////////////////
  PageModule.prototype.calcBaseBalanceAmount = function (eligibilityAmount, submittedRequests) {
    console.log('==================calcBaseBalanceAmount==========================');
    console.log(eligibilityAmount, submittedRequests);

    let result = (parseFloat(eligibilityAmount, 2) - parseFloat(submittedRequests, 2)).toFixed(2);
    console.log(result);

    if (isNaN(result)) {
      result = 0;
    }

    return parseFloat(result).toFixed(2);
  };

  ///////////////////////////////////////////////////////////////
  PageModule.prototype.getMinMaxAge = function (minMaxAge) {
    console.log('==================getMinMaxAge==========================');
    ///^[0-9]+-[0-9]+$
    if (minMaxAge.match(/^([0-9]+\s+-\s+[0-9]+)$/)) {
      return {
        minAge: minMaxAge.split('-')[0].trim(),
        maxAge: minMaxAge.split('-')[1].trim()
      };
    }
    return {
      minAge: 4,
      maxAge: 19
    };
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.checkVisaValidation = function (contactPersonId, familyVisaDetArr) {
    console.log("===================checkVisaValidation==================");
    let result = [];

    if (!familyVisaDetArr) {
      result.push({
        familyMemberResult: "The Visa details for the child is not defined, please contact the adminstrator"
      });
      return result;
    }

    ///////////////////Visa Validation
    var familyMemberVisa = familyVisaDetArr.find(e => e.contactPersonId == contactPersonId);

    if (!PageModule.prototype.isEmpty(familyMemberVisa)) {

      if (!PageModule.prototype.isEmpty(familyMemberVisa.expirationDate)) {
        var checkDate = new Date();
        var expirationDate = new Date(familyMemberVisa.expirationDate);
        if (checkDate.getTime() > expirationDate.getTime()) {
          console.log(familyMemberVisa)
          result.push({
            familyMemberResult: "The Visa of the child is expired, please contact the adminstrator"
          });
        }
      } else {
        console.log(familyMemberVisa)
        //   console.log(obj);
        result.push({
          familyMemberResult: "The Visa of the child is not valid, please contact the adminstrator"
        });
      }

    } else {
      console.log(contactPersonId);
      result.push({
        familyMemberResult: "The Visa of the child is not defined, please contact the adminstrator"
      });
    }

    console.log(result);
    return result;

  };

  PageModule.prototype.isEmpty = function (obj) {
    return !obj || obj == "";
  };

  return PageModule;
});
