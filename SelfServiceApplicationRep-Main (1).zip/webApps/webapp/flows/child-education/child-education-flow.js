/*
  Copyright (c) 2018, Oracle and/or its affiliates.
  The Universal Permissive License (UPL), Version 1.0
*/
define(['vb/helpers/rest'], function (Rest) {
  'use strict';

  var FlowModule = function FlowModule() { };


  /////////////////////////////////////////////////////////////////////////
  ////////////////////////////////////////////////////////////////////////
  FlowModule.prototype.searchByKey = function (arr, objKey, objValue) {
    return arr.find(e => e[objKey] == objValue);
  };
  ////////////////////////////////////////////////////////////////////////////
  //////////////////////////////////////////////////////////////////////////////
  FlowModule.prototype.isEmpty = function (obj) {
    return !obj || obj == "";
  };
  /////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  /////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  FlowModule.prototype.getISOFormatedDate = function (date) {
    var self = this;
    var finaldate = '';
    if (date) {
      var dateConverterFactory = oj.Validation.converterFactory(oj.ConverterFactory.CONVERTER_TYPE_DATETIME);
      self.dateConverter = dateConverterFactory.createConverter({ pattern: "dd-MMM-yyyy" });
      var formattedDate = self.dateConverter.format(oj.IntlConverterUtils.dateToLocalIso(new Date(date)));
      finaldate = formattedDate.split('T')[0];
      console.log(finaldate);
    }
    return finaldate;
  };

  ////////////////////////////////////////////////////////////////////////////
  //////////////////////////////////////////////////////////////////////////
  FlowModule.prototype.parseChildsCountJSON = function (jsonStrArr) {
    let result = [];
    jsonStrArr.forEach(jsonStr => {
      let obj = JSON.parse(jsonStr.jsonRow);
      result.push(obj);
    });

    console.log("#####################parseChildsCountJSON################");
    console.log(result);
    return result;
  };

  ///////////////////////////////////////////////////////////////////////////////////////
  ///////////////////////////////////////////////////////////////////////////////////////
  FlowModule.prototype.validChild = function (childsArr, personId, ignoreEmptyName, year) {

    return {
      validate: (contactPerId) => {
        return new Promise(function (resolve, reject) {

          let valid = true;

          let found = childsArr.some((e) => e.contactPersonId == contactPerId);
          if (found) {
            var endpoint = Rest.get(
              'ics/postXXYAS_COMMON_LOV1_0GetLovData'
            );

            endpoint.parameters({
              "lovName": 'YAS_EA_PREV_CH_CNT'
            });

            endpoint.body({
              "XxLOVParameters": [
                {
                  "parameter": personId
                },
                {
                  "parameter": contactPerId
                },
                {
                  "parameter": year
                }
              ]
            });

            document.getElementById("loading").style.display = "block";

            var resultCallback = endpoint.fetch();

            resultCallback.then(function (payload) {

              document.getElementById("loading").style.display = "none";

              if (payload.response.status === 200) {
                if (payload.body.XxLOVResult) {
                  let result = FlowModule.prototype.parseChildsCountJSON(payload.body.XxLOVResult)[0];
                  if (result.childs > 3) {
                    valid = false;
                    reject({
                      summary: 'Error',
                      detail: 'Maximum three children are eligible for education allowance, please contact HR officer or correct the eligibility for three children'
                    });
                  } else {
                    resolve();
                  }
                } else {
                  valid = false;
                  reject({
                    summary: 'Error',
                    detail: 'Cannot Read Your Data, Please Contact the Adminstrator'
                  });
                }
              }
            });

            let childRow = childsArr.find((e) => e.contactPersonId == contactPerId);
            console.log("test school");
            console.log(childRow);
            //check if school is empty
            if (FlowModule.prototype.isEmpty(childRow.childSchool)) {
              valid = false;
              reject({
                summary: 'Error',
                detail: 'Child School is Empty value, Please Contact the Adminstrator'
              });
            }

          } else if (!found) {
            if (!ignoreEmptyName) {
              valid = false;
              reject({
                summary: 'Error',
                detail: 'Select Child'
              });
            }
          }
          //return valid;
        });
      },
    };
  };



  // Calculate First, Last Day for Year & AcademicYear
  ////////////////////////////////////////////////////////////////////////////////////////////////////////////
  ////////////////////////////////////////////////////////////////////////////////////////////////////////////
  ////////////////////////////////////////////////////////////////////////////////////////////////////////////  
  FlowModule.prototype.calcFirstLastDay = function (year, academicYear) {
    var months = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];
    var firstDay = new Date();
    var lastDay = new Date();


    let firstYearMonth = months.indexOf(academicYear.split("-")[0].toUpperCase());
    let lastYearMonth = months.indexOf(academicYear.split("-")[1].toUpperCase());

    let firstYear = year.split("-")[0];
    let lastYear = year.split("-")[1];

    firstDay.setFullYear(firstYear, firstYearMonth, 10);
    lastDay.setFullYear(lastYear, lastYearMonth, 10);

    firstDay = new Date(firstDay.getFullYear(), firstDay.getMonth(), 1);
    lastDay = new Date(lastDay.getFullYear(), lastDay.getMonth() + 1, 0);

    return {
      "firstDay": firstDay,
      "lastDay": lastDay
    };

  };
  ////////////////////////////////////////////////////////////////////////////////////////////////////////////
  ///////////////////////////////////////////////////////////////////////////////////////////////////////////
  //////////////////////////////////////////////////////////////////////////////////////////////////////////
  FlowModule.prototype.calcFirstLastDayProration = function (year, academicYear, empHireDate) {
    var months = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];
    var firstDay = new Date();
    var lastDay = new Date();


    let firstYearMonth = months.indexOf(academicYear.split("-")[0].toUpperCase());
    let lastYearMonth = months.indexOf(academicYear.split("-")[1].toUpperCase());

    let firstYear = year.split("-")[0];
    let lastYear = year.split("-")[1];

    firstDay.setFullYear(firstYear, firstYearMonth, 10);
    lastDay.setFullYear(lastYear, lastYearMonth, 10);

    firstDay = new Date(firstDay.getFullYear(), firstDay.getMonth(), 1);
    lastDay = new Date(lastDay.getFullYear(), lastDay.getMonth() + 1, 0);

    if (firstDay.getTime() < new Date(empHireDate).getTime()) {
      firstDay = empHireDate;
    }

    return {
      "firstDay": firstDay,
      "lastDay": lastDay
    };

  };


  ////////////////////////////////////////////////////////////////////////////////////////////////////////////
  ////////////////////////////////////////////////////////////////////////////////////////////////////////////
  ////////////////////////////////////////////////////////////////////////////////////////////////////////////
  FlowModule.prototype.getNumberOfDays = function (start, end) {
    const date1 = new Date(start);
    console.log('date1', date1);
    const date2 = new Date(end);
    console.log('date2', date2);
    // One day in milliseconds
    const oneDay = 1000 * 60 * 60 * 24;
    // Calculating the time difference between two dates
    const diffInTime = date2.getTime() - date1.getTime();
    // Calculating the no. of days between two dates
    const diffInDays = Math.round(diffInTime / oneDay);
    console.log('diffInDays', diffInDays);
    return diffInDays;
  };


  ////////////////////////////////////////////////////////////////////////////////////////////////////////////
  ////////////////////////////////////////////////////////////////////////////////////////////////////////////
  ////////////////////////////////////////////////////////////////////////////////////////////////////////////
  FlowModule.prototype.calcEmployeeProporation = function (hireDate, lastDay, gradeRate, dayRate, academicYear) {
    console.log("====================calcEmployeeProporation========================");
    ///calculate Employee Proporation
    let employeeDays = FlowModule.prototype.getNumberOfDays(hireDate, lastDay) + 1;
    console.log("days: ", employeeDays);

    if (employeeDays < 0) {
      return {
        "result": "FAILURE",
        "msg": "Child Academic Year is " + academicYear + " and the Employee has joined after the end of this academic year"
      };
    }

    if (employeeDays > 365) {
      console.log('Employee has been joined more than one year');
      console.log(gradeRate);
      return {
        "result": "SUCCESS",
        "msg": "Employee has been joined more than one year",
        "eligibilityAmount": gradeRate
      };
    } else {
      var eligibilityAmountEmp = (dayRate * employeeDays).toFixed(2);
      console.log("Employee has been joined less than one year");
      console.log(eligibilityAmountEmp);
      return {
        "result": "SUCCESS",
        "msg": "Employee has been joined less than one year",
        "eligibilityAmount": eligibilityAmountEmp
      };
    }
  };


  ////////////////////////////////////////////////////////////////////////////////////////////////////////////
  ////////////////////////////////////////////////////////////////////////////////////////////////////////////
  ////////////////////////////////////////////////////////////////////////////////////////////////////////////
  FlowModule.prototype.calcChildProporation = function (childDOB, firstDay, lastDay, gradeRate, dayRate, academicYear, minAge, maxAge, gradesArr) {
    console.log("====================calcChildProporation========================");
    console.log("gradesArr= ", gradesArr)
    ///Calculate Child Proparation
    const fourYearsConst = (Number(minAge) - 1) * 365;       // 4 years = 1460 day
    const fiveYearsConst = Number(minAge) * 365;           // 5 years = 1825 day
    const eigthteenConst = (Number(maxAge) - 1) * 365;       // 18 year = 6570 day
    const ninteenYearsConst = Number(maxAge) * 365;           // 19 year = 6935 day

    console.log(fourYearsConst, fiveYearsConst, eigthteenConst, ninteenYearsConst);

    let NORMAL_CASE = true;
    if (gradesArr != undefined) {
      if (gradesArr.length > 1) {
        NORMAL_CASE = false;
      }
    }

    console.log("normalCase= ", NORMAL_CASE);

    let childAgeDaysFD = FlowModule.prototype.getNumberOfDays(childDOB, firstDay);
    let childAgeDaysLD = FlowModule.prototype.getNumberOfDays(childDOB, lastDay);
    console.log("firstDay: ", firstDay);
    console.log("lastDay: ", lastDay);
    console.log("childAgeDaysFD: ", childAgeDaysFD);
    console.log("childAgeDaysLD: ", childAgeDaysLD);

    if (childAgeDaysLD < fiveYearsConst) {
      console.log("Child age less than " + minAge + " years old for the end of the academic year");
      return {
        "result": "FAILURE",
        "msg": "Child age less than " + minAge + " years old at the end of the academic year"
      };
    }

    if (childAgeDaysFD > ninteenYearsConst) {
      console.log('Child Academic Year is ' + academicYear + '. Child became ' + maxAge + ' years old befor the start of the academic year');
      return {
        "result": "FAILURE",
        "msg": "Child Academic Year is " + academicYear + ". Birth Date: " + FlowModule.prototype.getISOFormatedDate(childDOB) + ". Child became " + maxAge + " years old befor the start of the academic year"
      };
    }

    var childAgeDate5Years = new Date(childDOB);
    var childAgeDate19Years = new Date(childDOB);
    if (NORMAL_CASE) {
      console.log("--------------the normal case-----------------");
      if (childAgeDaysFD >= fourYearsConst && childAgeDaysFD <= fiveYearsConst) {
        console.log("Child will become " + minAge + " years old before the end of the academic year");
        // var childAgeDate5Years = new Date(childDOB);
        childAgeDate5Years.setFullYear(childAgeDate5Years.getFullYear() + Number(minAge));
        console.log("childAgeDate5Years: ", childAgeDate5Years);
        let childDays = FlowModule.prototype.getNumberOfDays(childAgeDate5Years, lastDay) + 1;
        console.log("childDays: ", childDays);
        let eligibilityAmountChild = (dayRate * childDays).toFixed(2);
        console.log("eligibilityAmountChild: ", eligibilityAmountChild);
        return {
          "result": "SUCCESS",
          "msg": "Child will become " + minAge + " years old before the end of the academic year",
          "eligibilityAmount": eligibilityAmountChild
        };
      }

      if (childAgeDaysFD >= eigthteenConst && childAgeDaysFD <= ninteenYearsConst) {
        console.log("Child will become " + maxAge + " years old after the start of the academic year");
        // var childAgeDate19Years = new Date(childDOB);
        childAgeDate19Years.setFullYear(childAgeDate19Years.getFullYear() + Number(maxAge));
        console.log("childAgeDate19Years: ", childAgeDate19Years);
        let childDays = FlowModule.prototype.getNumberOfDays(firstDay, childAgeDate19Years) + 1;
        console.log("childDays: ", childDays);
        let eligibilityAmountChild = (dayRate * childDays).toFixed(2);
        console.log("eligibilityAmountChild: ", eligibilityAmountChild);
        return {
          "result": "SUCCESS",
          "msg": "Child will become " + maxAge + " years old after the start of the academic year",
          "eligibilityAmount": eligibilityAmountChild
        };
      }

    } else {
      console.log("--------------the spetial case-----------------");
      if (childAgeDaysFD >= fourYearsConst && childAgeDaysFD <= fiveYearsConst) {
        console.log("Child will become " + minAge + " years old before the end of the academic year");

        childAgeDate5Years.setFullYear(childAgeDate5Years.getFullYear() + Number(minAge));
        console.log("childAgeDate5Years: ", childAgeDate5Years);

        let eligibilityAmountChild = FlowModule.prototype.calcGradePromotionRate(gradesArr, childAgeDate5Years, lastDay);

        return {
          "result": "SUCCESS",
          "msg": "Child will become " + minAge + " years old before the end of the academic year",
          "eligibilityAmount": eligibilityAmountChild
        };

      }


      if (childAgeDaysFD >= eigthteenConst && childAgeDaysFD <= ninteenYearsConst) {
        console.log("Child will become " + maxAge + " years old after the start of the academic year");

        childAgeDate19Years.setFullYear(childAgeDate19Years.getFullYear() + Number(maxAge));
        console.log("childAgeDate19Years: ", childAgeDate19Years);

        let eligibilityAmountChild = FlowModule.prototype.calcGradePromotionRate(gradesArr, firstDay, childAgeDate19Years);
        console.log("eligibilityAmountChild: ", eligibilityAmountChild);
        return {
          "result": "SUCCESS",
          "msg": "Child will become " + maxAge + " years old after the start of the academic year",
          "eligibilityAmount": eligibilityAmountChild
        };
      }


    }

    console.log("Child is between " + minAge + " and " + maxAge + " years old in this academic year");
    return {
      "result": "SUCCESS",
      "msg": "Child is between " + minAge + " and " + maxAge + " years old in this academic year",
      "eligibilityAmount": gradeRate
    };

  };

  ////////////////////////////////////////////////////////////////////////////////////////////////////////////
  ////////////////////////////////////////////////////////////////////////////////////////////////////////////
  ////////////////////////////////////////////////////////////////////////////////////////////////////////////
  FlowModule.prototype.calcEligibilityAmount = function (hireDate, childDOB, gradeRate, year, academicYear, minAge, maxAge, gradesArr) {

    console.log("=========calcEligibilityAmount===========");
    console.log("gradesArr= ", gradesArr);

    if (year == -1) {
      console.log('Please Select Valid Year');
      return {
        "result": "FAILURE01",
        "msg": "Please Select Year!"
      };
    }

    if (academicYear == "" || !academicYear) {
      return {
        "result": "FAILURE",
        "msg": "Child Academic Year is invalid. Please contact Adminstrator to assign valid Academic Year for this child!"
      };
    }

    if (FlowModule.prototype.isEmpty(academicYear) || !academicYear.includes("-")) {
      console.log('Please Select Valid Academic Year');
      return {
        "result": "FAILURE",
        "msg": "Child Academic Year is " + academicYear + ". Please contact Adminstrator to assign valid Academic Year for this child!"
      };
    }

    let dayRate = gradeRate / 365;
    console.log("dayRate: ", dayRate);

    var fisrtLastDayObj = FlowModule.prototype.calcFirstLastDayProration(year, academicYear, hireDate);

    var firstDay = fisrtLastDayObj.firstDay;
    var lastDay = fisrtLastDayObj.lastDay;

    console.log("firstDay: ", firstDay);
    console.log("lastDay: ", lastDay);

    ///calculate Employee Proporation
    console.log("==calculate Employee Proporation==");
    var empPropObj = FlowModule.prototype.calcEmployeeProporation(hireDate, lastDay, gradeRate, dayRate, academicYear);
    console.log(empPropObj);

    if (empPropObj.result == "FAILURE" || empPropObj.result == "FAILURE01") {
      return empPropObj;
    } else {

      ///calculate Employee Proporation
      console.log("==calculate Child Proporation==");
      // var childPropObj = FlowModule.prototype.calcChildProporation(childDOB, firstDay, lastDay, empPropObj.eligibilityAmount, dayRate, academicYear);
      // console.log(childPropObj);

      var childPropObj = FlowModule.prototype.calcChildProporation(childDOB, firstDay, lastDay, gradeRate, dayRate, academicYear, minAge, maxAge, gradesArr);
      console.log(childPropObj);

      if (childPropObj.result == "FAILURE" || childPropObj.result == "FAILURE01") {
        return childPropObj;
      } else {

        let probObj = Number(childPropObj.eligibilityAmount) < Number(empPropObj.eligibilityAmount) ? childPropObj : empPropObj;
        console.log(probObj);
        return probObj;

      }

      // return childPropObj;
    }


  };


  ///=====================
  FlowModule.prototype.validChildForEligibilty = function (hireDate, gradeRate, year, childsArr, minAge, maxAge) {
    return {
      validate: (contactPersonId) => {
        console.log("validChildForEligibilty: ", contactPersonId);
        let valid = true;
        let found = childsArr.some((e) => e.contactPersonId == contactPersonId);
        console.log("found", found);
        if (found) {
          let childObj = FlowModule.prototype.searchByKey(childsArr, 'contactPersonId', contactPersonId);
          var childDOB = childObj.contactDob;
          var academicYear = childObj.academicYear;

          var eligibilityAmountResult = FlowModule.prototype.calcEligibilityAmount(hireDate, childDOB, gradeRate, year, academicYear, minAge, maxAge);
          console.log("result, ", eligibilityAmountResult);

          if (eligibilityAmountResult.result == "FAILURE" || eligibilityAmountResult.result == "FAILURE01") {
            valid = false;
            throw new Error(eligibilityAmountResult.msg);
          }

        }
        return valid;
      },
    };
  };


  //////////////////////////////////////////////////////////////////////
  // FlowModule.prototype.filterChilds = function (childsArr, year, minAge, maxAge) {
  //   console.log('================filterChilds==============');
  //   let result = [];

  //   const fourYearsConst    = (Number(minAge)-1) * 365;       // 4 years = 1460 day
  //   const fiveYearsConst    = Number(minAge) * 365;           // 5 years = 1825 day
  //   const eigthteenConst    = (Number(maxAge)-1) * 365;       // 18 year = 6570 day
  //   const ninteenYearsConst = Number(maxAge) * 365;           // 19 year = 6935 day

  //   if (year == -1) {
  //     return result;
  //   }

  //   result = childsArr.filter(function (e) {
  //     //console.log(e.contactName, e.academicYear, e.contactDob);
  //     if (FlowModule.prototype.isEmpty(e.academicYear) || !e.academicYear.includes("-")) {
  //       return false;
  //     }

  //     var fisrtLastDayObj = FlowModule.prototype.calcFirstLastDay(year, e.academicYear);
  //     var firstDay = fisrtLastDayObj.firstDay;
  //     var lastDay = fisrtLastDayObj.lastDay;
  //    // console.log(firstDay, lastDay);

  //     let childAgeDaysFD = FlowModule.prototype.getNumberOfDays(e.contactDob, firstDay);
  //     let childAgeDaysLD = FlowModule.prototype.getNumberOfDays(e.contactDob, lastDay);

  //     if(childAgeDaysLD < fiveYearsConst || childAgeDaysFD > ninteenYearsConst){
  //       return false;
  //     }

  //     return true;
  //   });

  //   console.log(result);
  //   return result;
  // };

  // FlowModule.prototype.filterChilds = function (childsArr, year, minAge, maxAge) {
  //   function getNumberOfDays(start, end) {
  //     const date1 = new Date(start);
  //     const date2 = new Date(end);

  //     if (isNaN(date1.getTime()) || isNaN(date2.getTime())) {
  //       console.error('Invalid date(s):', start, end);
  //       return NaN;
  //     }

  //     const oneDay = 1000 * 60 * 60 * 24;
  //     const diffInTime = date2.getTime() - date1.getTime();

  //     const diffDays = Math.floor(diffInTime / oneDay);
  //     return diffDays;
  //   }

  //   const today_date = new Date(new Date().setHours(0, 0, 0, 0));

  //   const minAgeDays = Number(minAge) * 365;
  //   const maxAgeDays = Number(maxAge) * 365;

  //   if (year === -1) {
  //     return [];
  //   }

  //   const filtered = childsArr.filter(child => {
  //     if (!child.academicYear || !child.academicYear.includes("-")) {
  //       return false;
  //     }

  //     const childAgeDays = getNumberOfDays(child.contactDob.slice(0, 10), today_date);

  //     if (childAgeDays < minAgeDays) {
  //       return false;
  //     }
  //     if (childAgeDays > maxAgeDays) {
  //       return false;
  //     }

  //     return true;
  //   });

  //   console.log('Filtered result:', filtered);
  //   return filtered;
  // };






  ////////////////////////////////////////////////////////////////////////////
  /////////////////////////////////////////////////////////////////////////////
  ////////////////////////////////////////////////////////////////////////////
  FlowModule.prototype.removeGradePromotionRatesDublicate = function (arr, academicStartDate, academicEndDate) {
    console.log("=================removeGradePromotionRatesDublicate====================");
    // let result = Object.values(arr.reduce((obj, { personId, grade, gradeRate, startDate, endDate }) => {
    //   if (obj[grade]) {
    //     if (obj[grade].endDate < endDate) obj[grade] = { personId, grade, gradeRate, startDate, endDate };
    //   } else obj[grade] = { personId, grade, gradeRate, startDate, endDate };

    //   return obj;
    // }, {}));

    let result = [];

    result = arr.filter(function (obj, index) {
      //return !FlowModule.prototype.isEmpty(obj.gradeRate);
      if (!FlowModule.prototype.isEmpty(obj.gradeRate)) {
        var endDate = new Date(obj.endDate);
        console.log(endDate.getFullYear());
        if (!(endDate.getFullYear() == 4712 && index != (arr.length - 1))) {
          return obj;
        }
      }
    });
    if (!FlowModule.prototype.isEmpty(academicStartDate) && !FlowModule.prototype.isEmpty(academicEndDate)) {
      result = result.filter(function (obj, index) {
        var endDate = new Date(obj.endDate);
        if (endDate.getTime() >= new Date(academicStartDate).getTime()) {
          return obj;
        }
      });
    }
    console.log(result);

    return result;
  };
  ////////////////////////////////////////////////////////////////////////////////
  //////////////////////////////////////////////////////////////////////////////////
  //////////////////////////////////////////////////////////////////////////////////



  FlowModule.prototype.filterChilds = function (childsArr, year, minAge, maxAge) {
    console.log('filterChilds');
    console.log(childsArr);
    console.log(year);
    console.log(minAge);
    console.log(maxAge);

    function getNumberOfDays(start, end) {
      const date1 = new Date(start);
      const date2 = new Date(end);

      if (isNaN(date1.getTime()) || isNaN(date2.getTime())) {
        console.error('Invalid date(s):', start, end);
        return NaN;
      }

      const oneDay = 1000 * 60 * 60 * 24;
      const diffInTime = date2.getTime() - date1.getTime();

      const diffDays = Math.floor(diffInTime / oneDay);
      return diffDays;
    }

    const today_date = new Date(new Date().setHours(0, 0, 0, 0));

    const minAgeDays = Number(minAge) * 365;
    const maxAgeDays = Number(maxAge) * 365;

    if (year === -1) {
      return [];
    }

    const filtered = childsArr.filter(child => {
      if (!child.academicYear || !child.academicYear.includes("-")) {
        return false;
      }

      const childAgeDays = getNumberOfDays(child.contactDob.slice(0, 10), today_date);

      if (childAgeDays < minAgeDays) {
        return false;
      }
      if (childAgeDays > maxAgeDays) {
        return false;
      }

      return true;
    });

    console.log('Filtered result:', filtered);
    return filtered;
  };


  ////////////////////////////////////////////////////////////////////////////////
  //////////////////////////////////////////////////////////////////////////////////
  //////////////////////////////////////////////////////////////////////////////////
  FlowModule.prototype.calcGradePromotionRate = function (gradesArr, academicStartDate, academicEndDate) {
    console.log("====================calcGradePromotionRate====================");
    console.log(academicStartDate, academicEndDate);
    let promotedGradeRate = 0;

    gradesArr = gradesArr.filter(e => new Date(e.endDate).getTime() > new Date(academicStartDate).getTime());

    if (gradesArr.length == 1) {
      promotedGradeRate = Number(gradesArr[0].gradeRate);
    } else {
      gradesArr.forEach((obj, indx) => {
        console.log("obj: ", obj);

        if (Number(obj.grade) <= 5 || FlowModule.prototype.isEmpty(obj.gradeRate)) {
          console.log('Employee is not eligible for education allowance at grade ', obj.grade);
        } else {
          var noDays = 0;
          var dayRate = Number(obj.gradeRate) / 365;
          var gradeRateRow = 0;
          if (indx == 0) {
            console.log('first row at grade ', obj.grade);
            noDays = FlowModule.prototype.getNumberOfDays(academicStartDate, obj.endDate) + 1;
            console.log('noDays= ', noDays);
          } else if (indx != (gradesArr.length - 1)) {
            console.log('middle row at grade ', obj.grade);
            noDays = FlowModule.prototype.getNumberOfDays(obj.startDate, obj.endDate) + 1;
            console.log('noDays= ', noDays);
          } else if (indx == (gradesArr.length - 1)) {
            console.log('last row at grade ', obj.grade);
            noDays = FlowModule.prototype.getNumberOfDays(obj.startDate, academicEndDate) + 1;
            console.log('noDays= ', noDays);
          }
          console.log('dayRate= ', dayRate);

          gradeRateRow = noDays * dayRate;
          console.log('gradeRateRow= ', gradeRateRow);
          promotedGradeRate = promotedGradeRate + gradeRateRow;

        }

      });
    }
    console.log('promotedGradeRate= ', promotedGradeRate);
    return promotedGradeRate.toFixed(2);
  };


  return FlowModule;
});