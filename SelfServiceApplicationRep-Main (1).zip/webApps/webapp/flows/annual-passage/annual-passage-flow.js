define([], function() {
  'use strict';

  var FlowModule = function FlowModule() {};

  FlowModule.prototype.isEmpty = function (obj) {
    return !obj || obj == "";
  };
  ///////////////////////////////////////////////////////////////////////////////

  FlowModule.prototype.returnDateDepartureDateValidator = function(departureDate) {
    return [{
      validate: (returnDate) => {
               if (returnDate&&departureDate) {
                 departureDate=departureDate.split('T')[0];
          const valid = returnDate >= departureDate;
          
          if (!valid) {
            throw new Error('Return Date Should be greater than Departure Date');
          }
          return valid;
        }
      },
    }];
  };


  FlowModule.prototype.departureDateReturnDateValidator = function(returnDate) {
    return [{
      validate: (departureDate) => {
               if (returnDate&&departureDate) {
                 returnDate=returnDate.split('T')[0];
          const valid = returnDate >= departureDate;
          
          if (!valid) {
            throw new Error('Return Date Should be greater than Departure Date');
          }
          return valid;
        }
      },
    }];
  };

  FlowModule.prototype.familyReturnDateDepartureDateValidator = function(departureDate) {
    return [{
      validate: (returnDate) => {
               if (returnDate&&departureDate) {
                 departureDate=departureDate.split('T')[0];
          const valid = returnDate >= departureDate;
          
          if (!valid) {
            throw new Error('Return Date(Family) Should be greater than Departure Date(Family)');
          }
          return valid;
        }
      },
    }];
  };

  ///////////////////////////////////////////////////////////////////////////////////
  FlowModule.prototype.familyDepartureDateReturnDateValidator = function(returnDate) {
    return [{
      validate: (departureDate) => {
               if (returnDate&&departureDate) {
                 returnDate=returnDate.split('T')[0];
          const valid = returnDate >= departureDate;
          
          if (!valid) {
            throw new Error('Return Date(Family) Should be greater than Departure Date(Family)');
          }
          return valid;
        }
      },
    }];
  };

  //////////////////////////////////////////////////////////////////////////////////
  FlowModule.prototype.enhanceAnnualPassageLines = function (arr) {
    console.log("====================enhanceAnnualPassageLines========================")
    console.log(arr);
    arr.forEach(e => {


      if (e.contactDob) {
        e.contactDob = e.contactDob.split('T')[0];
      }

      if (e.passExpirationDate) {
        e.passExpirationDate = e.passExpirationDate.split('T')[0];
      }

    });

    console.log(arr);
    return arr;

  };
  
  /////////////////////////////////////////////////////////
  FlowModule.prototype.formatDate = function(dateObj){
    if(dateObj){
      dateObj = dateObj.split('T')[0];
    }
    return dateObj;
  };

  /////////////////////////////////////////////////////////
  FlowModule.prototype.checkVisaValidation = function(linesArr, familyVisaDetArr, familyReturnDate, empPassExpiryDate){
    console.log("===================checkVisaValidation==================");
    let result = [];
    // if(!familyVisaDetArr){
    //   result.push({
    //       familyMemberResult : "The Visa details for contacts is not valid, please contact the adminstrator"
    //     });
    //   return result;
    // }
    // linesArr.forEach(obj => {
      
    //   var familyMemberVisa = familyVisaDetArr.find(e => e.contactPersonId == obj.contactPersonId);
    //   console.log(familyMemberVisa)
    //   if(!FlowModule.prototype.isEmpty(familyMemberVisa.expirationDate)){
    //     var checkDate = new Date();
    //     console.log(checkDate)
    //     var expirationDate = new Date(familyMemberVisa.expirationDate);
    //     console.log(expirationDate)
    //     if(checkDate.getTime() > expirationDate.getTime()){
    //       console.log(familyMemberVisa)
    //       console.log(obj);
    //       result.push({
    //       familyMemberResult : "The Visa of "+ familyMemberVisa.contactName + " is not valid, please contact the adminstrator"
    //     });
    //     }
    //   }else{
    //     console.log(familyMemberVisa)
    //       console.log(obj);
    //     result.push({
    //       familyMemberResult : "The Visa of "+ familyMemberVisa.contactName + " is not valid, please contact the adminstrator"
    //     });
    //   }
    // });
    if(!familyVisaDetArr && linesArr.length > 0){
      result.push({
          familyMemberResult : "The Visa details for contacts is not valid, please contact the adminstrator"
        });
      return result;
    }
    linesArr.forEach(obj => { 
      
      ///////////////////Visa Validation
      var familyMemberVisa = familyVisaDetArr.find(e => e.contactPersonId == obj.contactPersonId);
      
      if(!FlowModule.prototype.isEmpty(familyMemberVisa)){

      if(!FlowModule.prototype.isEmpty(familyMemberVisa.expirationDate)){
        var checkDate = new Date();
        var expirationDate = new Date(familyMemberVisa.expirationDate);
        if(checkDate.getTime() > expirationDate.getTime()){
          console.log(familyMemberVisa)
          console.log(obj);
          result.push({
          familyMemberResult : "The Visa of "+ familyMemberVisa.contactName + " is not valid, please contact the adminstrator"
        });
        }
      }else{
        console.log(familyMemberVisa)
          console.log(obj);
        result.push({
          familyMemberResult : "The Visa of "+ familyMemberVisa.contactName + " is not valid, please contact the adminstrator"
        });
      }

      }else{
        console.log(obj);
          result.push({
          familyMemberResult : "The Visa of "+ obj.contactName + " is not defined, please contact the adminstrator"
        });
      }
    

      //////////////////////////////Passport Validation
      if(!FlowModule.prototype.isEmpty(obj.passExpirationDate)){

        var currDate = new Date();
        var passExpirationDate = new Date(obj.passExpirationDate);
        if(currDate.getTime() > passExpirationDate.getTime()){
          console.log(obj);
          result.push({
          familyMemberResult : "The Passport of "+ obj.contactName + " is not valid, please contact the adminstrator"
        });
        }
        
      }else{
        result.push({
          familyMemberResult : "The Passport of "+ obj.contactName + " is not valid, please contact the adminstrator"
        });
      }


    });

    if(!FlowModule.prototype.isEmpty(empPassExpiryDate)){

        var sysDate = new Date();
        var empPassExpiryDateDate = new Date(empPassExpiryDate);
        if(sysDate.getTime() > empPassExpiryDateDate.getTime()){
          result.push({
          familyMemberResult : "The Passport of the Employee is not valid, please contact the adminstrator"
        });
        }
        
      }else{
        result.push({
          familyMemberResult : "The Passport of the Employee is not valid, please contact the adminstrator"
        });
      }

    console.log(result);
    return result;

  };


   ///////////////////////////////////////////////////////////////////////////
  FlowModule.prototype.searchByKey = function (arr, objKey, objValue) {
    return arr.find(e => e[objKey] == objValue);
  };
  ///////////////////////////////////////////////////////////////////////////
  ////////////////////////////////////////////////////////////////////////////////////////////////////////////
  FlowModule.prototype.getNumberOfDays = function(start, end) {
      const date1 = new Date(start);
      const date2 = new Date(end);
      // One day in milliseconds
      const oneDay = 1000 * 60 * 60 * 24;
      // Calculating the time difference between two dates
      const diffInTime = date2.getTime() - date1.getTime();
      // Calculating the no. of days between two dates
      const diffInDays = Math.round(diffInTime / oneDay);

      return diffInDays;
  };

  ///=====================
  FlowModule.prototype.validChildForEligibilty = function (childsArr) {
    return {
      validate: (contactPersonId) => {
        console.log("validChildForEligibilty: ",contactPersonId);        
        let valid = true;
        let found = childsArr.some((e) => e.contactPersonId == contactPersonId);
        console.log("found", found);
        if(found){
          let childObj = FlowModule.prototype.searchByKey(childsArr, 'contactPersonId', contactPersonId);
          var childDOB = childObj.contactDob;

          if(FlowModule.prototype.isEmpty(childDOB)){
            valid = false;
            throw new Error('Kindly add Date of birth for this child!');
          }else{
            const ninteenYearsConst = 19 * 365;           // 19 year = 6935 day
            let childAgeDays = FlowModule.prototype.getNumberOfDays(childDOB, new Date());
            if(childAgeDays >= ninteenYearsConst){
              valid = false;
              throw new Error('This Child is not eligible for annual passage request, age is greater than 19 !');
            }
          }
          
        }
        return valid;
      },
    };
  };

  return FlowModule;
});