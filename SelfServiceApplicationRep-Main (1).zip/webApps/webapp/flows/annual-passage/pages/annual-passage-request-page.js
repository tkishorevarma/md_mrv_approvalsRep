define([], function() {
  'use strict';

  var PageModule = function PageModule() {};

PageModule.prototype.testData = function(params) {
  console.log('test data is ',params);
}

  return PageModule;
});
