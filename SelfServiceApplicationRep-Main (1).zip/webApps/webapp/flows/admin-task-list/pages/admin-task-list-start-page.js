define(['ojs/ojarraydataprovider', 'ojs/ojkeyset', 'knockout'], function (ArrayDataProvider, keyset, ko) {
  'use strict';

  var PageModule = function PageModule() { };


  PageModule.prototype.selectedItems = ko.observable(new keyset.KeySetImpl());

  /////////////////////////////////////////
  PageModule.prototype.toTitleCase = function (str) {
    if (str != null) {
      let arr = str.split("_");
      let result = arr.map(e => { if (e.length > 3) return e.charAt(0).toUpperCase() + e.substr(1).toLowerCase(); else return e })
      return result.join(" ");
    }
    return str;

  };

  /////////////////////////////////////////////////////////////////////////////////
  PageModule.prototype.splitStringFromProcesInstance = function (description) {
    var result = {
      "moduleName":"",
      "moduleKeyName":"",
      "moduleReqId":"",
      "requestNo":"",
      "requestId":"",
      "requesterRole":"",
      "personNumber":"",
      "personName":"",
      "lineId":"",
      "approvalLevel":""
    };
    console.log(description);
    if (description != undefined && description) {
      var res = description.split("~");
      result.moduleName = this.getModuleName(res[0]);
      result.moduleKeyName = res[0];
      result.moduleReqId = res[1];
      result.requestNo = res[2];
      result.requestId = res[3];
      result.requesterRole = res[4];
      result.personNumber = res[5];
      result.personName = res[6];
      result.lineId = res[7];
      result.approvalLevel = res[8];

    }
    //console.log(result);
    return result;
  };


  ////////////////////////////////////////////////////////////////////////////////////
  PageModule.prototype.statusStyle = function (status) {
    console.log("=================statusStyle=================");
    console.log(status);
    let statusColor = "black";
    if (status == "ALERTED" || status == "FAULTED_RECOVERABLE") {
      statusColor = "red";
    } else if (status == "ASSIGNED" || status == "OPEN") {
      statusColor = "blue";
    } else if (status == "COMPLETED") {
      statusColor = "lime";
    }

    return {
      color: statusColor
    };

  };

  //////////////////////////////////////////////////////////////////////////////////////
  PageModule.prototype.sortArrUpdatedDate = function (arr) {
    console.log("==================sortArrUpdatedDate===================");
    let result = arr.sort(function (a, b) {
      // Turn your strings into dates, and then subtract them
      // to get a value that is either negative, positive, or zero.
      return new Date(b.updatedDate) - new Date(a.updatedDate);
    });
    console.log(result);

    return result;
  };

  /////////////////////////////////////////////////////////////////////////////////////
  PageModule.prototype.getModuleName = function (moduleNameKey) {
    console.log("==================getProcessName====================");
    let moduleArr = [
      { key: "AIR_TICKET_ENCASHMENT", value: "Air Ticket Encachment" },
      { key: "ANNUAL_PASSAGE", value: "Annual Passage" },
      { key: "EDUCATION_ALLOWANCE", value: "Education Allowance" },
      { key: "LOCAL_BUS", value: "Local Business Travel/Training" },
      { key: "OVER_SEASES", value: "Overseas Business Travel/Training" }
    ];

    let moduleObj = moduleArr.find(o => o.key == moduleNameKey);

    let moduleName = moduleObj.value || moduleNameKey;

    return moduleName;
  };

  /////////////////////////////////////////////////////////////////////////////////////
  PageModule.prototype.getProcessName = function (processNameKey) {
    console.log("==================getProcessName====================");
    let processArr = [
      { key: "XXYASAirTicketProcess", value: "Air Ticket Encachment" },
      { key: "XXYASAnnualPassageProcess", value: "Annual Passage" },
      { key: "XXYASChildEducationProcess", value: "Education Allowance" },
      { key: "XXYASLoclBunsTrvlProcess", value: "Local Business Travel/Training" },
      { key: "XXYASOverSeasBusinessTrvlProcess", value: "Overseas Business Travel/Training" }
    ];

    let processObj = processArr.find(o => o.key == processNameKey);

    let processName = processObj.value || processNameKey;

    return processName;
  };

  /////////////////////////////////////////////////////////////////////////////////////
  PageModule.prototype.getAssignees = function (assigneesArr) {
    console.log("====================getAssignees======================");
    console.log(assigneesArr);
    let assignees = "";
    assigneesArr.items.forEach(function (e) {
      assignees = assignees + e.id + " ,";
    });

    assignees = assignees.substring(0, assignees.length - 1);

    return assignees;
  };


  /////////////////////////////////////////////////////////////////////////////////////
  PageModule.prototype.parseAuditTraffic = function (auditTraficXml) {

    let auditTrafic = auditTraficXml.replaceAll('&lt;', '<');
    return auditTrafic;
  };

  ////////////////////////////////////////////////////////////////////////////////////////
  PageModule.prototype.filterUsers = function (arr, obj) {
    console.log("==================filterUsers==================");
    if(!obj || obj == ""){
      return arr;
    }
    if(isNaN(obj)){      
      obj = obj.toLowerCase();
    }
    var newArray = [];
    newArray = arr.filter( user => (user.userName?user.userName:'').toLowerCase().includes(obj) || user.fullName.toLowerCase().includes(obj) || user.personNumber.includes(obj) );
    console.log(newArray);
    
    
    let uniqueArray = newArray.filter( (elem, index) => newArray.findIndex(obj => obj.userId === elem.userId) === index );
    
    console.log(uniqueArray);
    
    return uniqueArray;
  };
  /////////////////////////////////////////////////////////////////////////////////
  PageModule.prototype.isEmpty = function(str){
    if (typeof str == 'undefined' || !str || str.length === 0 || str === "" || !/[^\s]/.test(str) || /^\s*$/.test(str))
        return true;
    else
        return false;
  };

  ////////////////////////////////////////////////////////////////////////////////
  PageModule.prototype.search = function (tasksArr, searchObj) {
    console.log("=================search==================");

    if( PageModule.prototype.isEmpty(searchObj.moduleKeyName)){
      searchObj.moduleKeyName = "";
    }

    if( PageModule.prototype.isEmpty(searchObj.requestNo)){
      searchObj.requestNo = "";
    }

    if( PageModule.prototype.isEmpty(searchObj.assignee)){
      searchObj.assignee = "";
    }

    if( PageModule.prototype.isEmpty(searchObj.empName)){
      searchObj.empName = "";
    }


    var result = [];

    result = tasksArr.filter(
        task => (searchObj.moduleKeyName == PageModule.prototype.splitStringFromProcesInstance(task.longSummary).moduleKeyName || searchObj.moduleKeyName == '') && ( PageModule.prototype.splitStringFromProcesInstance(task.longSummary).requestNo.toLowerCase().includes(searchObj.requestNo.toLowerCase())  || searchObj.requestNo == '') && (PageModule.prototype.getAssignees(task.assignees).toLowerCase().includes(searchObj.assignee.toLowerCase()) || searchObj.assignee=='') && ( PageModule.prototype.splitStringFromProcesInstance(task.longSummary).personName.toLowerCase().includes(searchObj.empName.toLowerCase()) || PageModule.prototype.splitStringFromProcesInstance(task.longSummary).personNumber.includes(searchObj.empName) || searchObj.empName=='') 
        );

    
    console.log(result);

    return result;
  };

  ///////////////////////////////////////////////////////////////////////////////////
  PageModule.prototype.formateTasksForExport = function(tasksArr, personsArr){
    console.log("=================formateTasksForExport==================");
    // console.log(tasksArr);

    var result = [];
    tasksArr.forEach(obj => {

      var task = {};
      var assignees = PageModule.prototype.getAssignees(obj.assignees);
      if(assignees == "BPMWorkflowAdmin"){
        assignees = "";
      }
      var summary = PageModule.prototype.splitStringFromProcesInstance(obj.longSummary);
      task.moduleName = summary.moduleName;
      task.moduleReqId = summary.moduleReqId;
      task.requestNo = summary.requestNo;
      task.personNumber = summary.personNumber;
      task.personName = summary.personName;
      task.requestId = summary.requestId;
      task.approvalLevel = summary.approvalLevel;
      task.createdBy = obj.createdBy;
      task.assignees = assignees;
      task.processId = obj.processId;
      task.createdDate = obj.createdDate;

      var emp = personsArr.find(person => person.personNumber == summary.personNumber);
      if(!PageModule.prototype.isEmpty(emp)){
        task.legalEntity = emp.legalEntityName;
      }else{
        task.legalEntity = "";
      }

      result.push(task);
    });

    console.log(result);
    return result;
  };


  //FUNC -  join arr
  PageModule.prototype.prepareUsersArr = function (arr) {
    console.log("==========joinArrByKey=============");
    var identities = [];
    arr.forEach((obj) => {
      console.log({ obj });
      var user = {
        "id": obj.value,
        "type": "user"
      };
      identities.push(user);
    });
    console.log(identities);
    return identities;
  };
  
  ////////////////////////////////////////////////
  PageModule.prototype.checkSelectedItems = function(keySet){
    console.log("============checkSelectedItems================");
    console.log(keySet);
    return true;
  };

  return PageModule;
});
