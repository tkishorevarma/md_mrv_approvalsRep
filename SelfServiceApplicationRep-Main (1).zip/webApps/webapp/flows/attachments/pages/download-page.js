define([], function() {
  'use strict';

  var PageModule = function PageModule() {};

  PageModule.prototype.closeWindow = function () {
    close();
  };

  return PageModule;
});
