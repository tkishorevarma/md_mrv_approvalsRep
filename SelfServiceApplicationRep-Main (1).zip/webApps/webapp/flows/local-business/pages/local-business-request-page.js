define([], function () {
  'use strict';

  var PageModule = function PageModule() { };


  PageModule.prototype.validatecheckStartDate = function (startDate, hireDate) {
    const hireDateFormatted = new Date(hireDate);
    const startDateFormatted = new Date(startDate);
    const currentDate = new Date();

    hireDateFormatted.setHours(0, 0, 0, 0);
    startDateFormatted.setHours(0, 0, 0, 0);
    currentDate.setHours(0, 0, 0, 0);

    var threeMonthsbefore = new Date(currentDate);
    threeMonthsbefore.setMonth(currentDate.getMonth() - 3);

    if (startDateFormatted < threeMonthsbefore) {
      console.log('TEST', 'Selected date cannot be before 3 months from the present date.');
      return "Selected date cannot be before 3 months from the present date.";
    }

    if (hireDate && startDateFormatted < hireDateFormatted) {
      console.log('TEST', 'Selected date must be on or after the hire date.');
      return "Selected date must be on or after the hire date.";
    }
    console.log('TEST', 'true');
    return "true";
  };


  PageModule.prototype.validateDate = function (futureDate) {
    return [{
      validate: (value) => {
        if (value === null || String(value) === "") {
          throw new Error("This is a mandatory field.");
        }
        let options =
        {
          year: 'numeric',
          month: 'numeric',
          day: 'numeric'
        };
        let futureDateString = futureDate.toLocaleDateString("en-US", options);
        let enterredDate = new Date(value);
        if (enterredDate <= futureDate) {
          throw new Error("Entered date must be after " + futureDateString + ".");
        }
      }
    }];
  };


  PageModule.prototype.validTotalDays = function (startDate) {
    return {
      validate: (endDate) => {
        console.log("validTotalDays : ");
        let valid = true;
        if (startDate && endDate) {
          var days = (parseInt((((new Date(endDate) - new Date(startDate)) / 86400000) + 1) || 0)) || 0;
          valid = !isNaN(days) ? days <= 30 : true;
          console.log("validTotalDays : ", days);
          console.log("validTotalDays : ", valid);
          if (!valid) {
            throw new Error(
              'Please apply for max 30 days as the request for more than 30 days will be treated as long term assignment.'
            );
          }
        }
        return valid;
      },
    };
  };


  PageModule.prototype.validTotalDaysStartDate = function (endDate) {
    return {
      validate: (startDate) => {
        console.log("validTotalDays : ");
        let valid = true;
        if (startDate && endDate) {
          var days = (parseInt((((new Date(endDate) - new Date(startDate)) / 86400000) + 1) || 0)) || 0;
          valid = !isNaN(days) ? days <= 30 : true;
          console.log("validTotalDays : ", days);
          console.log("validTotalDays : ", valid);
          if (!valid) {
            throw new Error(
              'Please apply for max 30 days as the request for more than 30 days will be treated as long term assignment.'
            );
          }
        }
        return valid;
      },
    };
  };


  PageModule.prototype.compareIdenticalStrings = function (mainString, subString) {
    console.log('mainString: ', mainString);
    console.log('subString: ', subString);
    if (mainString === null || subString === null || mainString === '' || subString === '' || mainString === undefined || subString === undefined) {
      console.log('false: ');
      return false;
    }
    console.log('true: ');
    return mainString.toLowerCase().includes(subString.toLowerCase());
  };


  PageModule.prototype.validateJustification = function (justification) {
    console.log('justification: ', justification);
    if (justification.length() > 60) {
      return false;
    }
    console.log('true: ');
    return true;
  };

  return PageModule;
});
