define([], function () {
  'use strict';

  var PageModule = function PageModule() { };

  PageModule.prototype.toTitleCase = function (str) {
    if (str != null) {
      let arr = str.split("_");
      let result = arr.map(e => { if (e.length > 3) return e.charAt(0).toUpperCase() + e.substr(1).toLowerCase(); else return e })
      return result.join(" ");
    }
    return str;

  };

  /////////////////////////////////////////////////////////////////////////////////
  PageModule.prototype.splitStringFromProcesInstance = function (description) {
    var result = {};
    console.log(description);
    if (description != undefined && description) {
      var res = description.split("~");
      result.moduleName = this.getModuleName(res[0]);
      result.moduleKeyName = res[0];
      result.moduleReqId = res[1];
      result.requestNo = res[2];
      result.requestId = res[3];
      result.requesterRole = res[4];
      result.personName = res[6];
      result.lineId = res[7];
      result.approvalLevel = res[8];

    }
    console.log(result);
    return result;
  };


  ////////////////////////////////////////////////////////////////////////////////////
  PageModule.prototype.statusStyle = function (status) {
    console.log("=================statusStyle=================");
    console.log(status);
    let statusColor = "black";
    if (status == "ALERTED" || status == "FAULTED_RECOVERABLE") {
      statusColor = "red";
    } else if (status == "ASSIGNED" || status == "OPEN") {
      statusColor = "blue";
    } else if (status == "COMPLETED") {
      statusColor = "lime";
    }

    return {
      color: statusColor
    };

  };

  //////////////////////////////////////////////////////////////////////////////////////
  PageModule.prototype.sortArrUpdatedDate = function (arr) {
    console.log("==================sortArrUpdatedDate===================");
    let result = arr.sort(function (a, b) {
      // Turn your strings into dates, and then subtract them
      // to get a value that is either negative, positive, or zero.
      return new Date(b.updatedDate) - new Date(a.updatedDate);
    });
    console.log(result);

    return result;
  };

  /////////////////////////////////////////////////////////////////////////////////////
  PageModule.prototype.getModuleName = function (moduleNameKey) {
    console.log("==================getProcessName====================");
    let moduleArr = [
      { key: "AIR_TICKET_ENCASHMENT", value: "Air Ticket Encachment" },
      { key: "ANNUAL_PASSAGE", value: "Annual Passage" },
      { key: "EDUCATION_ALLOWANCE", value: "Education Allowance" },
      { key: "LOCAL_BUS", value: "Local Business Travel/Training" },
      { key: "OVER_SEASES", value: "Overseas Business Travel/Training" }
    ];

    let moduleObj = moduleArr.find(o => o.key == moduleNameKey);

    let moduleName = moduleObj.value || moduleNameKey;

    return moduleName;
  };

  /////////////////////////////////////////////////////////////////////////////////////
  PageModule.prototype.getProcessName = function (processNameKey) {
    console.log("==================getProcessName====================");
    let processArr = [
      { key: "XXYASAirTicketProcess", value: "Air Ticket Encachment" },
      { key: "XXYASAnnualPassageProcess", value: "Annual Passage" },
      { key: "XXYASChildEducationProcess", value: "Education Allowance" },
      { key: "XXYASLoclBunsTrvlProcess", value: "Local Business Travel/Training" },
      { key: "XXYASOverSeasBusinessTrvlProcess", value: "Overseas Business Travel/Training" }
    ];

    let processObj = processArr.find(o => o.key == processNameKey);

    let processName = processObj.value || processNameKey;

    return processName;
  };

  /////////////////////////////////////////////////////////////////////////////////////
  PageModule.prototype.getAssignees = function (assigneesArr) {
    console.log("====================getAssignees======================");
    console.log(assigneesArr);
    let assignees = "";
    assigneesArr.items.forEach(function (e) {
      assignees = assignees + e.id + ",";
    });

    assignees = assignees.substring(0, assignees.length - 1);

    return assignees;
  };


  /////////////////////////////////////////////////////////////////////////////////////
  PageModule.prototype.parseAuditTraffic = function (auditTraficXml) {
    console.log("===============parseAuditTraffic================");
    let auditTrafic = auditTraficXml.replaceAll('&lt;', '<');
    let auditTraficDetails = "";
    try{
    const parser = new DOMParser();
    let dom = parser.parseFromString(auditTraficXml, "application/xml");

    let dataObjValue = dom.getElementsByTagName("nstrgdfl:value")[0].childNodes[0].nodeValue;
    dom = parser.parseFromString(dataObjValue, "application/xml");

    auditTraficDetails = dom.getElementsByTagName("detail")[0].childNodes[0].nodeValue;
    }catch(err){
      return auditTrafic;
    }


    return auditTraficDetails;
  };

  ////////////////////////////////////////////////////////////////////////////////////////
  PageModule.prototype.filterUsers = function (arr, obj) {
    console.log("==================filterUsers==================");
    if(!obj || obj == ""){
      return arr;
    }
    if(isNaN(obj)){      
      obj = obj.toLowerCase();
    }
    var newArray = [];
    newArray = arr.filter( user => (user.userName?user.userName:'').toLowerCase().includes(obj) || user.fullName.toLowerCase().includes(obj) || user.personNumber.includes(obj) );
    console.log(newArray);
    
    
    let uniqueArray = newArray.filter( (elem, index) => newArray.findIndex(obj => obj.userId === elem.userId) === index );
    
    console.log(uniqueArray);
    
    return uniqueArray;
  };


  return PageModule;
});
