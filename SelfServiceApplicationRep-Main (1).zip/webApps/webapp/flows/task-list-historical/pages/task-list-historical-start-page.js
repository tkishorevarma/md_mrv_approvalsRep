define([], () => {
  'use strict';

  class PageModule {


    getHrOfficerIfExists(inputObj) {
      try {
        const repType = inputObj?.XXYASRepType;
        if (!Array.isArray(repType) || repType.length === 0) {
          return null;
        }

        const respNameStr = repType[0]?.resp_name;
        if (typeof respNameStr !== 'string') {
          return null;
        }
        const roles = respNameStr.split(',').map(role => role.trim().toUpperCase());
        console.log(roles);
        return roles.includes('HR_OFFICER');
      } catch (error) {
        return null;
      }
    }



    ///////////////////////////////////
    toTitleCase(str) {
      if (str != null) {
        let arr = str.split("_");
        let result = arr.map(e => { if (e.length > 3) return e.charAt(0).toUpperCase() + e.substr(1).toLowerCase(); else return e })
        return result.join(" ");
      }
      return str;

    };
    //////////////////////////////

    ///////////////////////////////
    isEmpty(obj) {
      return !obj || obj == "";
    };
    ////////////////////////////////

    //////////////////////////////
    filterTasks(tasksArr, searchObj) {
      console.log("=================search==================", tasksArr);

      if (PageModule.prototype.isEmpty(searchObj.moduleName)) {
        searchObj.moduleName = null;
      }

      if (PageModule.prototype.isEmpty(searchObj.requestNumber)) {
        searchObj.requestNumber = null;
      }

      if (PageModule.prototype.isEmpty(searchObj.personNameNumber)) {
        searchObj.personNameNumber = null;
      }

      var result = [];

      result = tasksArr.filter(task =>
        (searchObj.moduleName == null || task.moduleName === searchObj.moduleName) &&
        (searchObj.requestNumber == null ||
          (task.requestNumber || "").toLowerCase().includes(searchObj.requestNumber.toLowerCase())
        ) &&
        (searchObj.personNameNumber == null ||
          (task.fullName || "").toLowerCase().includes(searchObj.personNameNumber.toLowerCase()) ||
          (task.personNumber || "").includes(searchObj.personNameNumber)
        )
      );

      console.log(result);

      return result;
    };



  }

  return PageModule;
});
