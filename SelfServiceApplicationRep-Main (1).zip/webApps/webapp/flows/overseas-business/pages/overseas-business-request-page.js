define([], function () {
  'use strict';

  var PageModule = function PageModule() { };

  //////////////////////////////////////////////////////////////////////////////////////
  PageModule.prototype.getCurrDate = function () {
    const currentDate = new Date();
    const year = currentDate.getFullYear();
    const month = String(currentDate.getMonth() + 1).padStart(2, '0');
    const day = String(currentDate.getDate()).padStart(2, '0');
    const formattedDate = `${year}-${month}-${day}`;
    console.log(formattedDate);
    return formattedDate;
  };


  PageModule.prototype.test = function (obj) {
    console.log('test data is ', obj);
  };

  // new function for perdium value

  PageModule.prototype.perdiumValueCalFunc = function (
    eventStartDate,
    eventEndDate,
    perdiemValue,
    hsCountryArr,
    destination,
    totalDays
  ) {
    console.log('eventStartDate', eventStartDate);
    console.log('eventEndDate', eventEndDate);
    console.log('perdiemValue', perdiemValue);
    console.log('hsCountryArr', hsCountryArr);
    console.log('destination', destination);
    console.log('totalDays', totalDays);


    let perDiemAmount = 0;

    const parseDate = (dateString) => {
      const date = new Date(dateString);
      date.setHours(0, 0, 0, 0);
      return date;
    };
    const eventStart = parseDate(eventStartDate);
    const eventEnd = parseDate(eventEndDate);

    const getDays = (startDate, endDate) => {
      const differenceInMillis = endDate - startDate;
      return Math.ceil(differenceInMillis / (1000 * 3600 * 24));
    };

    const actualDays = getDays(eventStart, eventEnd) + 1; // Calculate days

    return actualDays; // Return the calculated per diem amount
  };

  PageModule.prototype.calculatetotalAmount = function (perdiem, hsCountryArr, destination, totalDays) {
    console.log('in hs amount calc');
    console.log('perdiem', perdiem); // Corrected spelling
    console.log('totalDays', totalDays); // Corrected camel case
    console.log('destination', destination);

    // // Ensure hsCountryArr has the expected structure
    // if (!Array.isArray(hsCountryArr)) {
    //   console.error('hsCountryArr is not an array');
    //   return perdiem * totalDays; // Return default value if input is invalid
    // }

    // Filter unique country meanings
    const filterhsCountryArr = [...new Set(hsCountryArr.map(item => item.meaning))];
    console.log('filterhsCountryArr', filterhsCountryArr);

    let perDiemAmount = Number(perdiem)  * totalDays;
    if (destination && filterhsCountryArr.includes(destination)) {
      if (totalDays > 0) {
        perDiemAmount += 500 * totalDays;
        console.log('inside loop perDiemAmount', perDiemAmount);
      }
    }

    console.log('final perDiemAmount', perDiemAmount);
    return perDiemAmount; // Return the calculated amount
  };


  PageModule.prototype.calculatePerDiem = function (legalEntity, employeeGrade, gradeArr, catPdApproval, destination, hsCountryArr, actualDays) {

    let perDiemAmount = 0;
    let gradeValue = 0;

    console.log('calculate perdiem values ', legalEntity, employeeGrade, gradeArr, catPdApproval, destination, hsCountryArr, actualDays);
    // List of specific legal entities
    const legalEntityList = ["Yas Holding LLC", "TARAF COMMUNITIES REAL ESTATE L.L.C", "TARAF DEVELOPMENT L.L.C"];

    if (legalEntityList.includes(legalEntity)) {
      // Get grade value from gradeArr for the employee's grade
      const gradeData = gradeArr.find((item) => item.grade === employeeGrade);
      if (gradeData) {
        gradeValue = gradeData.amount;
      }
    } else {
      // Categories for Per Diem approval
      const approvalCategories = ["GCEO", "DCEO", "CEO / GM", "CXOs", "Other Staff"];

      if (approvalCategories.includes(catPdApproval)) {
        // For grades 18 and above
        const gradeData = gradeArr.find(
          (item) => item.grade === employeeGrade && item.grade >= 18
        );
        if (gradeData) {
          gradeValue = gradeData.amount;
        }
      } else {
        // For grades 17 and below
        const gradeData = gradeArr.find(
          (item) => item.grade === employeeGrade && item.grade <= 17
        );
        if (gradeData) {
          gradeValue = gradeData.amount;
        }
      }
    }

    // Calculate the initial Per Diem amount
    perDiemAmount = gradeValue * actualDays;

    // Check if the destination is in the Hardship countries list
    if (hsCountryArr.includes(destination)) {
      perDiemAmount += 500 * actualDays;
    }

    return perDiemAmount;
  };


  // PageModule.prototype.calculateEventDays = function ({
  //   departureDate,
  //   eventStartDate,
  //   eventEndDate,
  //   returnDate,
  //   travelHours
  // }) {
  //   const parseDate = (dateString) => {
  //     const date = new Date(dateString);
  //     date.setHours(0, 0, 0, 0);
  //     return date;
  //   };
  //   const depDate = parseDate(departureDate);
  //   const eventStart = parseDate(eventStartDate);
  //   const eventEnd = parseDate(eventEndDate);
  //   const retDate = parseDate(returnDate);

  //   const isSameDay = (date1, date2) => date1.getTime() === date2.getTime();

  //   let actualDays = 0;
  //   let totalNumberOfDays = 0;

  //   const getDays = (startDate, endDate) => {
  //     const differenceInMillis = endDate - startDate;
  //     return Math.ceil(differenceInMillis / (1000 * 3600 * 24));
  //   };

  //   if (travelHours !== '7HOURSPLUS') {
  //     if (isSameDay(depDate, eventStart)) {
  //       actualDays = 2;
  //       totalNumberOfDays = 2;
  //     } else {
  //       actualDays = 2;
  //       totalNumberOfDays = 3;
  //     }
  //   } else {
  //     actualDays = getDays(eventStart, eventEnd) + 1;
  //     totalNumberOfDays = getDays(depDate, retDate) + 1;
  //   }

  //   return {
  //     actualDays,
  //     totalNumberOfDays
  //   };
  // };


  PageModule.prototype.calculateEventDays = function (overseas,
    departureDate,
    eventStartDate,
    eventEndDate,
    returnDate,
    travelHours
  ) {
    const parseDate = (dateString) => {
      const date = new Date(dateString);
      date.setHours(0, 0, 0, 0);
      return date;
    };
    console.log('printed data calculate days1 ', overseas, departureDate,
      eventStartDate,
      eventEndDate,
      returnDate,
      travelHours);

    const depDate = parseDate(departureDate);
    const eventStart = parseDate(eventStartDate);
    const eventEnd = parseDate(eventEndDate);
    const retDate = parseDate(returnDate);
    console.log('printed data calculate days1 ', departureDate,
      eventStartDate,
      eventEndDate,
      returnDate,
      travelHours);
    let actualDays = 0;
    const getDays = (startDate, endDate) => {
      const differenceInMillis = endDate - startDate;
      return Math.ceil(differenceInMillis / (1000 * 3600 * 24));
    };

    // Calculate actual event days
    actualDays = getDays(eventStart, eventEnd) + 1;
    console.log('printed data calculate days ', actualDays);

    // Calculate total number of days including travel adjustments
    const prefix = getDays(depDate, eventStart) > 0 ? 1 : 0;
    const suffix = getDays(eventEnd, retDate) > 0 ? 1 : 0;
    const travelAdjustment = travelHours === '7HOURSPLUS' ? 0 : -1;
    const additionalDays = prefix + suffix === 2 ? prefix + suffix + travelAdjustment : prefix + suffix;
    console.log('printed data calculate days ', additionalDays);
    return {
      actualDays,
      additionalDays,
    };
  };


  //////////////////////////////////////////////////////////////////////////////////////
  PageModule.prototype.returnDateEndDateValidator = function (officalEndDate) {
    return {
      validate: (returnDate) => {
        console.log("## OfficalEndDate--->", officalEndDate);
        console.log("## returnDate--->", returnDate);
        if (returnDate && officalEndDate) {
          officalEndDate = officalEndDate.split('T')[0];
          const valid = returnDate >= officalEndDate;

          if (!valid) {
            throw new Error('Return Date Should be greater than Official End Date');
          }
          return valid;
        }
      },
    };
  };

  //////////////////////////////////////////////////////////////////////////////////////
  PageModule.prototype.officalEndDateReturnDateValidator = function (returnDate) {
    return {
      validate: (officalEndDate) => {
        console.log("## OfficalEndDate--->", officalEndDate);
        console.log("## returnDate--->", returnDate);
        if (returnDate && officalEndDate) {
          officalEndDate = officalEndDate.split('T')[0];
          const valid = returnDate >= officalEndDate;

          if (!valid) {
            throw new Error('Return Date Should be greater than Official End Date');
          }
          return valid;
        }
      },
    };
  };

  ////////////////////////////////////////////////////////////////   
  PageModule.prototype.departureDateStartDateValidator = function (startDate) {
    return {
      validate: (departureDate) => {
        console.log("## startDate--->", startDate);
        console.log("## departureDate--->", departureDate);
        if (startDate && departureDate) {
          startDate = startDate.split('T')[0];
          const valid = departureDate <= startDate;
          if (!valid) {
            throw new Error('Official Start Date Should be greater than Departure Date');
          }
          return valid;
        }
      },
    };
  };

  ////////////////////////////////////////////////////////////////   
  PageModule.prototype.departureDateReturnDateValidator = function (returnDate) {
    return {
      validate: (departureDate) => {
        console.log("## returnDate--->", returnDate);
        console.log("## departureDate--->", departureDate);
        if (returnDate && departureDate) {
          returnDate = returnDate.split('T')[0];
          const valid = departureDate <= returnDate;
          if (!valid) {
            throw new Error('Return Start Date Should be greater than Departure Date');
          }
          return valid;
        }
      },
    };
  };

  ////////////////////////////////////////////////////////////////   
  PageModule.prototype.returnDateDepartureDateValidator = function (departureDate) {
    return {
      validate: (returnDate) => {
        console.log("## returnDate--->", returnDate);
        console.log("## departureDate--->", departureDate);
        if (returnDate && departureDate) {
          returnDate = returnDate.split('T')[0];
          const valid = departureDate <= returnDate;
          if (!valid) {
            throw new Error('Return Start Date Should be greater than Departure Date');
          }
          return valid;
        }
      },
    };
  };

  ////////////////////////////////////////////////////////////////   
  PageModule.prototype.startDateDepartureDateValidator = function (departureDate) {
    return {
      validate: (startDate) => {
        console.log("## startDate--->", startDate);
        console.log("## departureDate--->", departureDate);
        if (startDate && departureDate) {
          startDate = startDate.split('T')[0];
          const valid = departureDate <= startDate;
          if (!valid) {
            throw new Error('Official Start Date Should be greater than Departure Date');
          }
          return valid;
        }
      },
    };
  };

  /////////////////////////////////////////////////////////////////////////

  PageModule.prototype.validInputSearch = function () {
    return {
      validate: (value) => {
        console.log("validInputSearch : ", value);
        let valid = value.length > 5;
        if (!valid) {
          throw new Error(
            'Enter 6 or more characters.'
          );
        }
        return valid;
      },
    };
  };

  /////////////////////////////////////////////////////////////////////////

  PageModule.prototype.validTotalDays = function (departureDate, additionalDays) {
    return {
      validate: (returnDate) => {
        console.log("validTotalDays : ");
        let valid = true;
        if (returnDate && departureDate && additionalDays) {
          var days = (parseInt((((new Date(returnDate) - new Date(departureDate)) / 86400000) + 1) || 0) + parseInt(additionalDays)) || 0;
          valid = !isNaN(days) ? days <= 30 : true;
          console.log("validTotalDays : ", days);
          console.log("validTotalDays : ", valid);
          if (!valid) {
            throw new Error(
              'Please apply for max 30 days as the request for more than 30 days will be treated as long term assignment.'
            );
          }
        }
        return valid;
      },
    };
  };

  /////////////////////////////////////////////////////////////////////////

  /*PageModule.prototype.validTotalDays = function (days) {
    return {
      validate: (returnDate) => {
        console.log("validTotalDays : ", days);
        let valid = true;
        valid = !isNaN(days) ? days<=30 : true;
        console.log("validTotalDays : ", valid);
        if (!valid) {
          throw new Error(
            'Please apply for max 30 days as the request for more than 30 days will be treated as long term assignment.'
          );
        }
        return valid;
      },
    };
  };*/

  //////////////////////////////////////////////////////////////////////////

  PageModule.prototype.mergeArr = function (arr1, arr2) {
    console.log("====================mergeArr====================");
    var result = arr1.concat(arr2);
    console.log(result);
    return result;
  };



  return PageModule;
});
