define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ComboValueChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.value 
     * @param {string} params.testmeaning 
     */
    async run(context, { value, testmeaning }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      await Actions.fireNotificationEvent(context, {
        summary: 'iuytdr',
      });

      await $functions.test(testmeaning);
    }
  }

  return ComboValueChangeChain;
});
