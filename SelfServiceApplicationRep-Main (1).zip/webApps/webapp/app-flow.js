/*
  Copyright (c) 2018, Oracle and/or its affiliates.
  The Universal Permissive License (UPL), Version 1.0
*/
define(['ojs/ojcore', 'xlsx'], function (oj, xlsx) {
  'use strict';

  var AppModule = function AppModule() { };

  AppModule.prototype.newformatDate = function (dateString) {
    const date = new Date(dateString);
    if (isNaN(date)) return null;

    const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
      "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

    const day = String(date.getDate()).padStart(2, '0');
    const month = months[date.getMonth()];
    const year = date.getFullYear();
    console.log('chcekinggggggggggggggggggggggggg'+`${day}-${month}-${year}`.toUpperCase());
    return `${day}-${month}-${year}`.toUpperCase();
  };





  AppModule.prototype.openSpinnerDialog = function () {
    document.getElementById("loading").style.display = "block";
  };

  AppModule.prototype.closeSpinnerDialog = function () {
    document.getElementById("loading").style.display = "none";
  };
  AppModule.prototype.isFormValid = function (form) {
    var tracker = document.getElementById(form);
    if (tracker.valid === "valid") {
      return true;
    } else {
      tracker.showMessages();
      tracker.focusOn("@firstInvalidShown");
      return false;
    }
  }
  AppModule.prototype.isEmpty = function (obj) {
    return !obj || obj == "";
  };
  AppModule.prototype.logger = function (obj) {
    console.log("logger: ", obj);
  };

  AppModule.prototype.toTitleCase = function (str) {
    if (str != null) {
      let arr = str.split("_");
      let result = arr.map(e => { if (e.length > 3) return e.charAt(0).toUpperCase() + e.substr(1).toLowerCase(); else return e })
      return result.join(" ");
    }
    return str;

  };

  AppModule.prototype.toTitleCase2 = function (str) {
    if (str != null) {
      let arr = str.split("_");
      let result = arr.map(e => { return e.charAt(0).toUpperCase() + e.substr(1).toLowerCase(); })
      return result.join(" ");
    }
    return str;

  };

  AppModule.prototype.parseJSON = function (jsonStrArr, toCamelCase = true) {
    let result = [];
    console.log('json data is ', jsonStrArr);
    if (!AppModule.prototype.isEmpty(jsonStrArr)) {
      jsonStrArr.forEach(jsonStr => {
        if (!AppModule.prototype.isEmpty(jsonStr.jsonRow)) {
          let obj = JSON.parse(jsonStr.jsonRow);
          if (toCamelCase)
            result.push(AppModule.prototype.keysToCamel(obj));
          else result.push(obj);
        }
      });
    }
    console.log("#####################parseJSON################");
    console.log(result);
    // console.log(JSON.stringify(result))
    return result;
  };

  AppModule.prototype.isEmpty = function (obj) {
    return !obj || obj == "";
  };
  AppModule.prototype.keysToCamel = function (obj) {
    const result = {};
    Object.keys(obj)
      .forEach((k) => {
        result[AppModule.prototype.toCamel(k)] = obj[k];
      });
    return result;
  };
  AppModule.prototype.toCamel = function (str) {
    let strLower = str.toLowerCase();
    return strLower.replace(/([-_][a-z])/ig, ($1) => {
      return $1.toUpperCase()
        .replace('-', '')
        .replace('_', '');
    });
  };

  AppModule.prototype.checkExists = function (arr, obj, key) {
    return arr.filter(function (e) {
      return e[key] === obj[key];
    }).length > 0;

  };

  AppModule.prototype.readLocalFile = function (file) {
    var readDataPromise = new Promise(function (resolve) {
      //Create a File reader and its onload callback
      var fileReader = new FileReader();
      fileReader.onload = function (fileReadEvent) {
        var readData = fileReadEvent.target.result;
        resolve(readData);
      };
      fileReader.readAsBinaryString(file);

    });
    return readDataPromise;
  };

  AppModule.prototype.str2ab = function (str) {
    var buf = new ArrayBuffer(str.length);
    var bufView = new Uint8Array(buf);
    for (var i = 0, strLen = str.length; i < strLen; i++) {
      bufView[i] = str.charCodeAt(i);
    }
    return buf;
  };

  AppModule.prototype.ab2str = function (buf) {
    var binary = '';
    var bytes = new Uint8Array(buf);
    var len = bytes.byteLength;
    for (var i = 0; i < len; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return binary;
    //     var enc = new TextDecoder();
    //     var bufView = new Uint8Array(buf);
    // return enc.decode(bufView)
    //     return String.fromCharCode.apply(null, new Uint8Array(buf));
  };

  AppModule.prototype.createAttachment = function (file, moduleName,
    moduleRequestId, arrBuf) {
    console.log("createAttachment: ", file);

    let attachment = {
      "contentType": AppModule.prototype.isEmpty(file.type) ? "text/plain" : file.type,
      "moduleName": moduleName,
      "moduleReqId": moduleRequestId,
      "uploadedFile": arrBuf,
      "uploadedFileName": file.name,
      "uploadedFileSize": file.size
    };

    console.log("createAttachment: ", attachment);
    return attachment;
  };

  AppModule.prototype.modifyAllArrKeyValue = function (arr, key, value) {
    console.log("modify= ", arr);
    arr.forEach(e => {
      e[key] = value;
    });
    console.log("modify= ", arr);
    return arr;
  };

  AppModule.prototype.filterByKey = function (arr, objKey, objValue) {
    console.log("#################filterByKey###################");
    console.log("arr: ", arr);
    console.log("objKey: ", objKey);
    console.log("objValue: ", objValue);
    let result = arr.filter(item => item[objKey] == objValue);
    console.log("result: ", result);
    return result;
  };

  AppModule.prototype.toFormData = function (attachmentsArr) {

    let attachmentsArrLite = [];
    let formData = new FormData();

    attachmentsArr.forEach(attachment => {

      //remove the blob from each attachment before JSON.stringify
      const {
        uploadedFile,
        ...attachmentLite
      } = attachment;

      //reconstruct a file object from array buffer utf8 view
      let blob = new Blob([uploadedFile], { type: attachmentLite.contentType });

      formData.append("file[]", new File([blob], attachmentLite.uploadedFileName));

      attachmentsArrLite.push(attachmentLite);

    });

    formData.append('json', JSON.stringify({ "XXYASAttachments": attachmentsArrLite }));

    console.log("toFormData: ", formData.getAll('file[]'))
    console.log("toFormData: ", formData.getAll('json'))

    return formData;
  };

  AppModule.prototype.modifyArrInplace = function (arr, modifications, key) {
    arr.forEach(e => {
      modifications.forEach(m => {
        if (e[key] === m[key])
          Object.assign(e, m);
      });
    });
    return arr;
  };

  AppModule.prototype.cloneFileList = function (source) {
    let result = [];
    source.forEach(element => {
      result.push({
        uploadedFileName: element.uploadedFileName
      });
    });

    return result;
  };

  AppModule.prototype.parseMixedPayload = function (body) {
    // console.log("parseMixedPayload ", body);
    let str = AppModule.prototype.ab2str(body);
    // console.log("str ", str);
    const regex_boundary = /------=(\S+)/gu;
    const regex_binary = /Content-Disposition:.*[\r\n]+([^]+)/g;
    let m;
    let boundary = regex_boundary.exec(str)[1];
    let arr = str.split(boundary);

    //now we need to parsr arr for json body containg the metadata and for the actual file to download
    let result = {
      "attachments": []
    };

    arr.forEach(e => {
      let matches = regex_binary.exec(e);
      if (matches != null) {
        let file = matches[1];
        //push array buffer repsentation of the file
        result.attachments.push(AppModule.prototype.str2ab(file));
      }
    });
    console.log("result ", result);
    return result;
  };

  AppModule.prototype.download = function (arrbufferUTF8, fileName,
    fileType) {
    console.log("download: ", arrbufferUTF8);
    var blob = new Blob([arrbufferUTF8], {
      type: fileType
    });

    var link = document.createElement('a');
    link.href = window.URL.createObjectURL(blob);
    link.setAttribute("download", fileName);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  /////////////////////////////////////////////////////////////////////////////////////
  AppModule.prototype.getISOFormatedDate = function (date) {
    var self = this;
    var finaldate = '';
    if (date) {
      var dateConverterFactory = oj.Validation.converterFactory(oj.ConverterFactory.CONVERTER_TYPE_DATETIME);
      self.dateConverter = dateConverterFactory.createConverter({ pattern: "dd-MMM-yy HH:mm a " });
      var formattedDate = self.dateConverter.format(oj.IntlConverterUtils.dateToLocalIso(new Date(date)));
      finaldate = formattedDate.split('T')[0];
      console.log(finaldate);
    }
    return finaldate;
  };

  //////////////////////////////////////////////////////////////////////////////////////
  AppModule.prototype.formatDate = function (dateObj) {
    if (dateObj) {
      dateObj = dateObj.split('T')[0];
    }
    return dateObj;
  };

  ///////////////////////////////////////////////////////////////////////////////////
  AppModule.prototype.validLOV = function (arr, key) {
    return {
      validate: (value) => {
        console.log("ValidLOV: ", value);
        let valid = arr.some((element) => element[key] == value);
        if (!valid) {
          throw new Error(
            'Entered value is not correct'
          );
        }
        return valid;
      },
    };
  };

  AppModule.prototype.searchByKey = function (arr, objKey, objValue) {
    console.log(arr.find(e => e[objKey] == objValue));
    return arr.find(e => e[objKey] == objValue);
  };


  AppModule.prototype.checkFileListEquality = function (source, target) {
    console.log("#####################checkFileListEquality###############");
    console.log("compareObjects: ", source);
    console.log("compareObjects: ", target);
    //true means the 2 equal
    let result = true;
    if (source.length != target.length)
      return false;
    source.forEach(s => {
      let found = false;
      target.forEach(t => {
        if (s.uploadedFileName == t.uploadedFileName)
          found = true;
      });
      if (!found)
        result = false;
    });
    console.log("result: ", result);
    return result;
  };

  AppModule.prototype.checkArrayEq = function (source, target) {
    console.log("#####################checkArrayEq###############");
    console.log("source: ", source);
    console.log("target: ", target);
    //true means the 2 equal
    //assuming ordered arrays of the same length (equal elements appear at same index)
    let result = true;
    if (source.length == 0 && target.length == 0)
      return true;

    if (target.length == 0)
      return false;

    for (let i = 0; i < source.length; i++) {
      result = AppModule.prototype.compareObjects(source[i], target[i]);
      if (!result)
        break;
    }
    console.log("result: ", result);
    return result;
  };

  AppModule.prototype.compareObjects = function (source, target) {
    console.log("#####################compareObjects###############");
    console.log("source: ", source);
    console.log("target: ", target);
    if (AppModule.prototype.isEmpty(target) || AppModule.prototype.isEmpty(source)) {
      console.log("Source or Target is empty");
      return false;
    }
    for (let [key, value] of Object.entries(source)) {
      if (AppModule.prototype.isEmpty(source[key]) && AppModule.prototype
        .isEmpty(target[key]))
        continue;
      if (target[key] != value) {
        console.log("on key: ", key);
        return false;

      }
    }

    // true means 2 objects are same
    return true;
  };


  ////////////////////////////////////////
  AppModule.prototype.filterContacts = function (arr, objArr, key) {
    console.log("==================filterContacts==================");
    let result = arr.filter(item => !objArr.some(obj => item[key] == obj[key]));
    return result;
  };

  AppModule.prototype.filterContactsIgnore = function (arr, objArr, key, ignoreValue) {
    console.log("==================filterContactsIgnore==================");
    let result = arr.filter(item => !objArr.some(obj => item[key] == obj[key] && obj[key] != ignoreValue));
    return result;
  };

  ////////////////////////////////////////
  AppModule.prototype.contactsCount = function (arr, objValue, key) {
    console.log("==================contactsCount==================");
    let result = arr.filter(item => item[key] == objValue).length;
    return result;
  };


  //////////////////////////////////////////////////////
  AppModule.prototype.splitStringFromProcesInstance = function (description) {
    var result = {};
    if (description != undefined && description) {
      var res = description.split("~");
      // result.moduleName = this.toTitleCase(res[0]);
      // result.moduleKeyName = res[0];
      // result.moduleReqId = res[1];
      // result.requestNo = res[2];
      // result.requestId = res[3];
      // result.requesterRole = res[4];
      // result.personName = res[6];
      // result.lineId = res[7];
      // result.approvalLevel = res[8];
      // result.activeSwimLane = res[9];
      result.moduleName = this.toTitleCase(res[0]);
      result.moduleKeyName = res[0];
      result.moduleReqId = res[1];
      result.requestNo = res[2];
      result.personNumber = res[3];
      result.personName = res[4];
      result.approvalLevel = res[5];
      result.activeSwimLane = res[6];
    }
    console.log(result);
    return result;
  };


  AppModule.prototype.attachmentsCheck = function (task, attachmentData) {

    if (this.isValidApprovalLevel(task, 'Travel Desk Officer')) {
      const data = attachmentData?.data || [];
      return data.length > 0;
    } else {
      return true;
    }
  };

  //////////////////////////////////////////////////////////
  AppModule.prototype.isValidApprovalLevel = function (tasks, approvalLevel) {
    console.log("=============isValidApprovalLevel=============");
    let valid = false;
    console.log(tasks, approvalLevel);
    if (!AppModule.prototype.isEmpty(tasks.items) && tasks.items.length > 0) {
      var result = AppModule.prototype.splitStringFromProcesInstance(tasks.items[0].summary);
      console.log(result);
      if (result.approvalLevel === approvalLevel) {
        valid = true;
      }
    }

    return valid;
  };

  //////////////////////////////////////////////////////////
  AppModule.prototype.isValidApprovalLevelSwimLane = function (tasks, approvalLevel, activeSwimLane) {
    console.log("=============isValidApprovalLevelSwimLane=============");
    let valid = false;
    if (AppModule.prototype.isValidApprovalLevel(tasks, approvalLevel)) {
      var result = AppModule.prototype.splitStringFromProcesInstance(tasks.items[0].summary);
      console.log(result);
      if (result.activeSwimLane == activeSwimLane) {
        valid = true;
      }
    }
    return valid;
  };

  //////////////////////////////////////////////////////////
  AppModule.prototype.isEmptyArrByKey = function (arr, objKey) {
    console.log('isEmptyArrByKey');
    console.log(arr, objKey);
    let empty = false;

    arr.forEach(e => {
      console.log(e[objKey]);
      if (AppModule.prototype.isEmpty(e[objKey]))
        empty = true;
    });
    console.log(empty)
    return empty;
  };

  /////////////////////////////////////////////////////////
  AppModule.prototype.filterEmployees = function (personsArr, hrArr) {
    console.log("======================filterEmployees=======================");
    let result = [];
    if (personsArr.length > 0 && hrArr.length > 0) {
      result = personsArr.filter(p => hrArr.some(h => p.personId == h.person_id));
    }
    console.log(result);
    return result;
  };

  ////////////////////////////////////////////////////////////
  AppModule.prototype.filterSearchResults = function (resultsArr, hrArr, hrPersonId) {
    console.log("======================filterEmployees=======================");
    let result = [];
    if (resultsArr.length > 0 && hrArr.length > 0) {
      result = resultsArr.filter(res => hrArr.some(hr => res.personId == hr.person_id || res.requestedBy == hrPersonId));
    }
    console.log(result);
    return result;
  };

  ///////////////////////////////////////////////////////////
  AppModule.prototype.endDateStartDateValidator = function (startDate) {
    return {
      validate: (endDate) => {
        if (endDate && startDate) {
          const valid = endDate >= startDate;
          if (!valid) {
            throw new Error('End date must be start date or later');
          }
          return valid;
        }
      },
    };
  };
  ////////////////////////////////////////////////////////////////   
  AppModule.prototype.startDateEndDateValidator = function (endDate) {
    return {
      validate: (startDate) => {
        if (startDate && endDate) {
          const valid = endDate >= startDate;
          if (!valid) {
            throw new Error('Start date must before or equal End Date');
          }
          return valid;
        }
      },
    };
  };

  //////////////////////////////////////////////////////////////////
  AppModule.prototype.splitEmpTicketEligibilty = function (ticketEligibilty) {
    console.log("====================splitEmpTicketEligibilty=======================")
    let staff = 0, spouse = 0, childs = 0;
    if (!AppModule.prototype.isEmpty(ticketEligibilty)) {
      let arr = ticketEligibilty.split("+");
      console.log(arr, arr.length);
      if (arr.length == 1) {
        staff = arr[0].trim() == 'Not Eligible' ? 0 : arr[0].trim() == 'Staff Only' ? 1 : 0;
        //break;
      } else if (arr.length == 2) {
        staff = 1;
        spouse = isNaN(arr[1].trim()) ? 1 : 0;
        childs = !isNaN(arr[1].trim()) ? parseInt(arr[1].trim()) : 0;
      } else if (arr.length == 3) {
        staff = 1;
        spouse = 1;
        childs = parseInt(arr[2].trim());
      }

    }

    let empEligibility = {
      "staff": staff,
      "spouse": spouse,
      "childs": childs
    };

    console.log(empEligibility)
    return empEligibility;

  };

  /////////////////////////////////////////////////////////////////////
  AppModule.prototype.exportToExcel = function (heading, fields, data, fileName) {
    console.log("========================exportToExcel======================");
    console.log(xlsx.xlsx);
    var rowData = [];
    //add the header
    rowData.push(heading);
    //format the date to correct shape
    data.forEach(row => {
      var columnData = [];
      fields.forEach(field => {
        columnData.push(row[field]);
      });
      rowData.push(columnData);
    });
    console.log(rowData);

    //convert to excel sheet
    var wb = xlsx.utils.book_new();
    wb.Props = {
      Title: fileName,
    };
    wb.SheetNames.push(fileName);
    var ws = xlsx.utils.aoa_to_sheet(rowData);
    wb.Sheets[fileName] = ws;
    var wbout = xlsx.write(wb, {
      bookType: 'xlsx',
      type: 'binary'
    });

    //convert to octet stream
    var buf = new ArrayBuffer(wbout.length); //convert s to arrayBuffer
    var view = new Uint8Array(buf); //create uint8array as viewer
    for (var i = 0; i < wbout.length; i++) view[i] = wbout.charCodeAt(i) &
      0xFF; //convert to octet

    var blob = new Blob([view], {
      type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;'
    });

    var link = document.createElement('a');
    link.href = window.URL.createObjectURL(blob);
    link.setAttribute("download", fileName + ".xlsx");
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  ///////////////////////////////////////////////////////////////////////////
  AppModule.prototype.calcExactValue = function (module, travelType, region_tripLength, days) {
    console.log('========================Calc Exact Value========================');
    let exactValue = region_tripLength;

    if (module == 'OVER_SEASES') {
      exactValue = exactValue + ' ' + (travelType == 'BUS_TRV' ? 'Business Travel' : travelType == 'TR_TRV' ? 'Training Trip' : travelType);
      exactValue = exactValue + ' ' + (days < 16 ? '1 to 15 Days' : '16 to 30 Days');
    } else if (module == 'LOCAL_BUS') {
      exactValue = exactValue + ' ' + (travelType == 'BUS_TRV' ? 'Business Trip Local' : travelType == 'TR_TRV' ? 'Training TRIP Local' : travelType);
      // exactValue = exactValue + ' ' + days + ' Days';
      exactValue = exactValue + ' 30 Days';
    }

    console.log(exactValue);

    return exactValue;
  };

  ///////////////////////////////////////////////////////////////////////////////
  AppModule.prototype.getGrade = function (empGrade) {
    console.log("=================getGrade======================");

    let gradeNum = "";
    let gradeName = "";
    if (empGrade.match(/^([0-9]+)$/)) {
      //6
      gradeNum = empGrade;
    } else if (empGrade.match(/^([a-zA-Z]+\.[a-zA-Z]+\.[0-9]+)$/)) {
      //EAGP.Grade.6
      gradeNum = empGrade.split(".")[2];
    } else if (empGrade == 'YHL.Service Grade SP.A') {
      //YHL.Service Grade SP.A
      return empGrade.substring(empGrade.indexOf('.') + 1);
    } else if (empGrade.match(/^([a-zA-Z]+\.[a-zA-Z]+\s+[0-9]+\.[a-zA-Z]+[0-9]+)$/)) {
      //GHR.Grade 12.E3
      gradeNum = empGrade.split(".")[1];
    } else if (empGrade.match(/^([a-zA-Z]+\.[a-zA-Z]+\s+[0-9]+\.[a-zA-Z]+)$/)) {
      //GHR.Grade 12.E
      gradeNum = empGrade.split(".")[1];
    } else if (empGrade.match(/^([a-zA-Z]+\.[a-zA-Z]+\s+[a-zA-Z]+\s+[0-9]+\.[a-zA-Z]+)$/)) {
      //GHR.Service Grade 9.A
      gradeNum = empGrade.split(".")[1].split(" ")[2];
    }
    console.log(gradeNum);

    gradeName = isNaN(gradeNum) ? gradeNum : "Grade " + gradeNum;

    console.log(gradeName);

    return gradeName;

  };

  ///////////////////////////////////////////////////////////////////////////////
  AppModule.prototype.getPerdiemStructure = function (salaryBasis) {
    console.log("=======================getPerdiemStructure==========================");
    console.log(salaryBasis);
    let structure = salaryBasis;

    if (salaryBasis.match(/^([a-zA-Z]+\s+[0-9]+\s+[a-zA-Z]+)$/)) {
      structure = salaryBasis.replaceAll(" ", "_");
    } else if (salaryBasis.match(/^([a-zA-Z]+\s+[0-9]+\s+[a-zA-Z]+\s[a-zA-Z]+)$/)) {
      structure = salaryBasis.replaceAll(" ", "_");
      // structure = salaryBasis.split(" ")[0] + "_" + salaryBasis.split(" ")[1] + "_Structure";
    }

    console.log(structure);

    return structure;

  };

  ///////////////////////////////////////////////////////////////////////////////
  AppModule.prototype.checkServiceGrade = function (salaryBasis, grade) {
    console.log("============checkServiceGrade=============");
    if (AppModule.prototype.isEmpty(salaryBasis)) {
      grade = grade;
    } else {
      if (grade.includes("SP")) {
        grade = grade;
      } else if (salaryBasis.toUpperCase().includes("SERVICE")) {
        grade = "Service " + grade;
      }
    }
    console.log(grade);
    return grade;
  };

  /////////////////////////////////////////////////////////////////////////////
  AppModule.prototype.getHostName = function (url) {
    console.log("GET-HOST-URL");
    console.log(url)
    var liveUrl = url.split('webapp/')[0] + "webapp/";
    console.log(liveUrl);
    return liveUrl;
  };



  /////////////////////////////////////////////////////////////////////////////
  AppModule.prototype.validateEmpEligibltyFullReq = function (elgSpouseCount, elgChildsCount, linesArr, childsArr, spouseArr) {
    console.log("==================validateEmpEligibltyFullReq==================");

    if (linesArr.length == (elgSpouseCount + elgChildsCount)) {
      console.log("Valid");
      return "VALID";
    }

    if (elgSpouseCount == 0 && elgChildsCount == 0) {
      console.log("Valid");
      return "VALID";
    }

    let childsAdded = AppModule.prototype.contactsCount(linesArr, 'Child', 'concatRelationship');
    let spouseAdded = AppModule.prototype.contactsCount(linesArr, 'Spouse', 'concatRelationship');
    console.log(childsAdded, spouseAdded);

    let childsCount = childsArr.length || 0;
    let spouseCount = spouseArr.length || 0;
    console.log(childsCount, spouseCount);

    if (childsAdded < childsCount && childsAdded < elgChildsCount) {
      console.log("Childs InValid");
      return "INVALID";
    }

    if (spouseAdded < spouseCount && spouseAdded < elgSpouseCount) {
      console.log("Spouse InValid");
      return "INVALID";
    }

    return "VALID";

  };

  /////////////////////////////////////////////////////////////////////////////////
  AppModule.prototype.getDateFormated = function (dateObj) {
    console.log("=====================getDateFormated==========================");

    if (AppModule.prototype.isEmpty(dateObj)) {
      return dateObj;
    }

    const months = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];
    var current_datetime = new Date(dateObj);
    console.log(current_datetime);
    let formatted_date = current_datetime.getDate() + "-" + months[current_datetime.getMonth()] + "-" + current_datetime.getFullYear();
    console.log(formatted_date);

    return formatted_date;
  };
  /////////////////////////////////////////////////////////////////////
  ///////////////////////////////////////////////////////////////////////////////////
  AppModule.prototype.checkEmpAORResponsipilty = function (respName, aorTypes) {
    console.log("====================checkEmpAORResponsipilty===================");
    var empRespArr = respName.split(',');
    let result = [];
    let valid = false;
    if (empRespArr.length > 0 && aorTypes.length > 0) {
      result = aorTypes.filter(o1 => empRespArr.some(o2 => o1.aorCode === o2));
    }
    console.log(result);

    if (result.length > 0) {
      valid = true;
    }

    return valid;
  };
  /////////////////////////////////////////////////////////////////////////////////////////////

  // AppModule.prototype.getAssignee = function(tasksArr, processId){
  //   console.log("======================getAssignee========================",tasksArr,processId);

  //   var task = tasksArr.find(obj => obj.processId == processId);
  //   var assignees = "";
  //   if(!AppModule.prototype.isEmpty(task)){

  //     if(task.status == "ALERTED"){
  //       assignees = "There is an issue in assigning an approver, Please contact the Adminstartor!";

  //     }else{
  //       task.assignees.items.forEach(function (e) {
  //         assignees = assignees + e.id + ",";
  //       });

  //       assignees = assignees.substring(0, assignees.length - 1);
  //     }

  //   }

  //   return assignees;

  // };

  AppModule.prototype.getAssignee = function (tasksArr, processId) {
    console.log("tasks are ", tasksArr, processId);
    let assignees = [];

    for (let i = 0; i < tasksArr.length; i++) {
      const task = tasksArr[i];

      if (task.processInstanceId === processId || task.rootProcessId === processId) {
        if (task.assignee && task.assignee.displayName) {
          assignees.push(task.assignee.displayName);
        }
      }
    }

    // Join the assignee names with a comma separator
    return assignees.join(', ');
  };

  ////////////////////////////////////////////////////
  AppModule.prototype.parseAuditTraffic = function (auditTraficXml) {
    console.log("===============parseAuditTraffic================");
    let auditTrafic = auditTraficXml.replaceAll('&lt;', '<');
    let auditTraficDetails = "";
    try {
      const parser = new DOMParser();
      let dom = parser.parseFromString(auditTraficXml, "application/xml");

      let dataObjValue = dom.getElementsByTagName("nstrgdfl:value")[0].childNodes[0].nodeValue;
      dom = parser.parseFromString(dataObjValue, "application/xml");

      auditTraficDetails = dom.getElementsByTagName("detail")[0].childNodes[0].nodeValue;
    } catch (err) {
      return auditTrafic;
    }


    return auditTraficDetails;
  };

  return AppModule;
});

